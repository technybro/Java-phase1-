package phase1Project;

public class Welcome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Welcome page
		System.out.println("-----------Welcome to the project LockedMe-------------------");
		System.out.println("              Developed By : Harshit Bajpai                  ");
		System.out.println("           contact details:harshit199915@gmail.com           ");
		System.out.println("       for any querry Please feel free to contact us         ");
		
		System.out.println("=============================================================");
		//creating object to enter main menu
		Menu obj=new Menu();
		obj.MenuMethod();
	}

}
